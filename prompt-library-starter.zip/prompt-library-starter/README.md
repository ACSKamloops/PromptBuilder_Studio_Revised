# Prompt Library Starter (Reasoning • Grounding • Verification • Multimodal)

This starter kit gives you a **clickable, modular prompt library** you can drop into a website/tool.
It encodes the modern "Prompt Science" workflow: *reasoning architectures*, *knowledge grounding*, *verification loops*,
and the universal principle: **Structure precedes reasoning**.

## What’s inside
- `schemas/prompt_template.schema.json` — JSON schema for your prompt definitions
- `prompts/*.yaml` — 24 production-grade templates (CoT, ToT, GoT, RAG, KGoT-style journal, RSIP, CoV, SPOC cue, Charts-of-Thought, SoAL, Thinking with Tables, Caption-Assisted, CAD, MPS, CHI, and more)
- `compositions/*.yaml` — 4 recipes chaining templates (Deep Research, Long-Form Writing, Data Review, Strategic Planning)
- `ui/ui.blueprint.json` — minimal mapping of slot types → UI components
- `reproducibility/*` — protocol + evaluation rubric

## Conventions
- **Slots**: Each template declares `slots` with `{name, label, type, help, default}` → render as form controls.
- **Placeholders**: Use `{{placeholder}}` in `prompt` to interpolate slot values.
- **Combines**: `combines_with` suggests compatible templates to chain.
- **Acceptance**: Each template includes `acceptance_criteria` (wire these to your review UI).

## Quick start
1. Load any `prompts/*.yaml` and render its slots as a form.
2. On submit, render the `prompt` with slot interpolation and send to your model with `model_preferences.params`.
3. For **RAG**, insert retrieved passages into the `context` slot first.
4. For **verification**, add a secondary run with `chain-of-verification` or the RSIP template.
5. Log everything according to `reproducibility_protocol.md`.

## How to extend
- Add new templates following the schema. Keep *transcribe → analyze* for data/visual tasks.
- Add UI help: the `ui.blueprint.json` hints component choices and helpful notices.
- Build pipelines by chaining `compositions/*.yaml` or create your own.

---

**Note:** This starter is model-agnostic. Adjust `system` and `params` per model/version.
